package bj.sooru.citoyen;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.SslErrorHandler;
import android.webkit.WebChromeClient;
import android.webkit.PermissionRequest;
import android.net.http.SslError;
import android.util.Log;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.core.content.ContextCompat;

import com.getcapacitor.BridgeActivity;

import java.util.ArrayList;
import java.util.List;

/**
 * MainActivity — Point d'entrée de l'application Sóóru Citoyen.
 *
 * Hérite de BridgeActivity (Capacitor) qui configure automatiquement :
 * - La WebView avec le bon Viewport
 * - Le chargement des assets depuis www/
 * - Le bridge JavaScript ↔ Java pour les plugins Capacitor
 *
 * Ce fichier ajoute :
 * - Demande de permissions runtime (stockage, caméra)
 * - Configuration WebView renforcée
 */
public class MainActivity extends BridgeActivity {

    private static final String TAG = "SooruMain";

    // ── Launcher pour la demande groupée de permissions ──────────────────────
    private final ActivityResultLauncher<String[]> permissionLauncher =
        registerForActivityResult(
            new ActivityResultContracts.RequestMultiplePermissions(),
            results -> {
                results.forEach((permission, granted) -> {
                    if (!granted) {
                        Log.w(TAG, "Permission refusée : " + permission);
                    }
                });
                // L'app continue même si certaines permissions sont refusées.
                // Les fonctionnalités concernées seront simplement désactivées côté HTML.
            }
        );

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Demande les permissions au démarrage
        requestAllPermissions();

        // Configuration avancée de la WebView (après l'init Capacitor)
        configureWebView();
    }

    // ─────────────────────────────────────────────────────────────────────────
    // PERMISSIONS RUNTIME
    // ─────────────────────────────────────────────────────────────────────────

    private void requestAllPermissions() {
        List<String> permissionsToRequest = new ArrayList<>();

        // ── Caméra ──
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)
                != PackageManager.PERMISSION_GRANTED) {
            permissionsToRequest.add(Manifest.permission.CAMERA);
        }

        // ── Stockage selon la version Android ──
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            // Android 13+ : permissions granulaires par type de média
            addIfNotGranted(permissionsToRequest, Manifest.permission.READ_MEDIA_IMAGES);
            addIfNotGranted(permissionsToRequest, Manifest.permission.READ_MEDIA_VIDEO);
            addIfNotGranted(permissionsToRequest, Manifest.permission.READ_MEDIA_AUDIO);
        } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            // Android 11-12 : READ suffit (WRITE n'existe plus pour le stockage partagé)
            addIfNotGranted(permissionsToRequest, Manifest.permission.READ_EXTERNAL_STORAGE);
        } else {
            // Android ≤ 10 : READ + WRITE
            addIfNotGranted(permissionsToRequest, Manifest.permission.READ_EXTERNAL_STORAGE);
            addIfNotGranted(permissionsToRequest, Manifest.permission.WRITE_EXTERNAL_STORAGE);
        }

        // ── Notifications (Android 13+) ──
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            addIfNotGranted(permissionsToRequest, Manifest.permission.POST_NOTIFICATIONS);
        }

        if (!permissionsToRequest.isEmpty()) {
            permissionLauncher.launch(
                permissionsToRequest.toArray(new String[0])
            );
        }
    }

    private void addIfNotGranted(List<String> list, String permission) {
        if (ContextCompat.checkSelfPermission(this, permission)
                != PackageManager.PERMISSION_GRANTED) {
            list.add(permission);
        }
    }

    // ─────────────────────────────────────────────────────────────────────────
    // CONFIGURATION WEBVIEW
    // ─────────────────────────────────────────────────────────────────────────

    private void configureWebView() {
        WebView webView = getBridge().getWebView();
        if (webView == null) return;

        WebSettings settings = webView.getSettings();

        // ── Viewport et affichage ──
        settings.setUseWideViewPort(true);
        settings.setLoadWithOverviewMode(true);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);
        settings.setSupportZoom(false); // Désactive le pinch-to-zoom (design fixe)

        // ── JavaScript et DOM ──
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);

        // ── Stockage et cache ──
        settings.setCacheMode(WebSettings.LOAD_DEFAULT);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);

        // ── Accès fichiers entre origines (nécessaire pour charger des ressources locales) ──
        settings.setAllowFileAccessFromFileURLs(false); // false = plus sécurisé
        settings.setAllowUniversalAccessFromFileURLs(false);

        // ── Media ──
        settings.setMediaPlaybackRequiresUserGesture(false);

        // ── User-Agent : identifie l'app comme WebView Android ──
        String originalUA = settings.getUserAgentString();
        settings.setUserAgentString(originalUA + " SooruCitoyen/1.0");

        // ── WebChromeClient : gère les permissions JS (camera, micro, géoloc) ──
        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onPermissionRequest(final PermissionRequest request) {
                // Accorde les permissions demandées par la page JS
                // (ex: navigator.mediaDevices.getUserMedia)
                runOnUiThread(() -> request.grant(request.getResources()));
            }
        });

        // ── WebViewClient : gère les erreurs SSL ──
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public void onReceivedSslError(WebView view, SslErrorHandler handler, SslError error) {
                // ⚠ EN PRODUCTION : ne JAMAIS appeler handler.proceed() sur une vraie erreur SSL
                // Ici on bloque — le network_security_config est la vraie protection
                Log.e(TAG, "Erreur SSL : " + error.toString());
                handler.cancel(); // Bloque la navigation non sécurisée
            }
        });

        Log.d(TAG, "WebView configurée avec succès");
    }
}
