# proguard-rules.pro — Règles ProGuard/R8 pour Sóóru Citoyen
# R8 est activé en mode release pour réduire la taille de l'APK.

# ── Capacitor (OBLIGATOIRE) ─────────────────────────────────────────────────
# Ne pas obfusquer les classes Capacitor (appelées par reflection depuis JS)
-keep class com.getcapacitor.** { *; }
-keep @com.getcapacitor.annotation.CapacitorPlugin class * { *; }
-keepclassmembers class * extends com.getcapacitor.Plugin {
    @com.getcapacitor.annotation.PluginMethod public *;
}

# ── AndroidX / AppCompat ────────────────────────────────────────────────────
-keep class androidx.** { *; }
-keep interface androidx.** { *; }

# ── WebView JavaScript Interface ────────────────────────────────────────────
# Si vous ajoutez des interfaces JS custom (@JavascriptInterface), protégez-les :
# -keepclassmembers class bj.sooru.citoyen.** {
#     @android.webkit.JavascriptInterface <methods>;
# }

# ── Sérialisation JSON (si utilisée) ───────────────────────────────────────
-keepattributes Signature
-keepattributes *Annotation*
-keepattributes EnclosingMethod
-keepattributes InnerClasses

# ── Logs (supprimer en production) ─────────────────────────────────────────
-assumenosideeffects class android.util.Log {
    public static boolean isLoggable(java.lang.String, int);
    public static int v(...);
    public static int d(...);
    public static int i(...);
}

# ── Garder le nom des classes pour les stack traces ──────────────────────────
-keepattributes SourceFile,LineNumberTable
-renamesourcefileattribute SourceFile
